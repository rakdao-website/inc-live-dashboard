from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ZoneRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    zone_id: str
    zone_name: str
    zone_type: str
    is_bookable: bool
    is_closed: bool
    status: str
    pulse: bool


class ActivityItem(BaseModel):
    feed_id: str
    occurred_at: datetime
    category: str
    action: str
    message: str


class DashboardResponse(BaseModel):
    generated_at: datetime
    map: list[ZoneRead]
    metrics: dict[str, int]
    ecosystem: dict[str, object] | None
    sectors: list[dict[str, object]]
    events: list[dict[str, object]]
    activity_feed: list[ActivityItem]
