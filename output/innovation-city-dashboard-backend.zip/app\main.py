from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.config import get_settings
from app.database import Base, SessionLocal, engine, get_db
from app.models import ActivityFeed, Booking, EcosystemMetric, Event, Sector, Zone
from app.schemas import DashboardResponse, ZoneRead
from app.seed import seed_sample_data
from app.services import activity_message, now_dubai, schedule_status, zones_with_status


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings = get_settings()
    if settings.auto_create_tables:
        Base.metadata.create_all(bind=engine)
    if settings.seed_sample_data:
        with SessionLocal() as db:
            seed_sample_data(db)
    yield


app = FastAPI(title="Innovation City Live Dashboard API", version="1.0.0", lifespan=lifespan)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/dashboard", response_model=DashboardResponse)
def dashboard(db: Session = Depends(get_db)) -> dict:
    now = now_dubai()
    zone_data = zones_with_status(db)
    events = db.scalars(select(Event).options(joinedload(Event.zone)).order_by(Event.event_date, Event.event_time_start)).all()
    latest_ecosystem = db.scalar(select(EcosystemMetric).order_by(EcosystemMetric.snapshot_date.desc()))
    sectors = db.scalars(select(Sector).order_by(Sector.display_order)).all()
    feed = db.scalars(select(ActivityFeed).options(joinedload(ActivityFeed.zone), joinedload(ActivityFeed.event).joinedload(Event.zone), joinedload(ActivityFeed.booking).joinedload(Booking.zone)).order_by(ActivityFeed.occurred_at.desc()).limit(20)).all()
    occupied = sum(z["status"] == "occupied" for z in zone_data)
    active_meetings = sum(z["status"] == "occupied" and z["zone_type"] == "meeting_room" for z in zone_data)
    return {
        "generated_at": now, "map": zone_data,
        "metrics": {"zones_occupied": occupied, "zones_total": sum(z["is_bookable"] for z in zone_data), "meetings_active": active_meetings, "events_today_count": sum(e.event_date == now.date() for e in events)},
        "ecosystem": None if not latest_ecosystem else {"snapshot_date": latest_ecosystem.snapshot_date, "active_companies": latest_ecosystem.active_companies, "active_licenses": latest_ecosystem.active_licenses, "top_sector": latest_ecosystem.top_sector},
        "sectors": [{"name": s.sector_name, "company_count": s.company_count, "display_order": s.display_order} for s in sectors],
        "events": [{"event_id": e.event_id, "name": e.event_name, "date": e.event_date, "start": e.event_time_start, "end": e.event_time_end, "location": e.event_location, "zone": e.zone.zone_name, "status": schedule_status(e.event_date, e.event_time_start, e.event_time_end, now)} for e in events],
        "activity_feed": [{"feed_id": f.feed_id, "occurred_at": f.occurred_at, "category": f.category, "action": f.activity_action, "message": activity_message(f)} for f in feed],
    }


@app.get("/api/zones", response_model=list[ZoneRead])
def list_zones(db: Session = Depends(get_db)) -> list[dict]:
    return zones_with_status(db)

